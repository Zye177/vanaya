<?php
$emailku = 'vanaya177@gmail.com';
?>